

aries= document.querySelector('aries')
taurus= document.querySelector('taurus')
gemini= document.querySelector('gemini')
cancer= document.querySelector('cancer')
leo= document.querySelector('leo')
virgo = document.querySelector('virgo')
libra= document.querySelector('libra')
scorpio= document.querySelector('scorpio')
sag= document.querySelector('sagittarius')
cap= document.querySelector('capricorn')
aquarius= document.querySelector('aquarius')
pisces= document.querySelector('pisces')

document.querySelector('#submit').addEventListener('click', findMyZodiac)

function findMyZodiac(){
    let bdayMonth = document.querySelector('input#month').value
    bdayMonth = bdayMonth.toLowerCase()
    let bDay= document.querySelector('input#day').value

    if (bdayMonth === "january" && bDay <= 20 ) {
            document.querySelector('#placeTextHere').innerText = 'Capricorn!'
            aquarius.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            cap.classList.toggle('hidden')


        } else if (bdayMonth === "january" &&  bDay >= 21){
            document.querySelector('#placeTextHere').innerText = 'Aquarius!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.toggle('hidden')
        } else if (bdayMonth === "february" && bDay <= 18) {
            document.querySelector('#placeTextHere').innerText = 'Aquarius!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.toggle('hidden')
        } else if (bdayMonth === "february" && bDay >= 19){
            document.querySelector('#placeTextHere').innerText = 'Pisces!'
            cap.classList.add('hidden')
            pisces.classList.toggle('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "march" && bDay <= 20) {
            document.querySelector('#placeTextHere').innerText = 'Pisces!'
            cap.classList.add('hidden')
            pisces.classList.toggle('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "march"  &&  bDay >= 21){
            document.querySelector('#placeTextHere').innerText = 'Aries!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.toggle('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "april" && bDay <= 19) {
            document.querySelector('#placeTextHere').innerText = 'Aries!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.toggle('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "april" && bDay >= 20){
            document.querySelector('#placeTextHere').innerText = 'Taurus!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.toggle('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "may" && bDay <= 20 ) {
            document.querySelector('#placeTextHere').innerText = 'Taurus!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.toggle('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "may" && bDay >= 21){
            document.querySelector('#placeTextHere').innerText = 'Gemini!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.toggle('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "june" && bDay <= 20 ) {
            document.querySelector('#placeTextHere').innerText = 'Gemini!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.toggle('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "june" && bDay >= 21){
            document.querySelector('#placeTextHere').innerText = 'Cancer!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.toggle('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "july" && bDay <= 22 ) {
            document.querySelector('#placeTextHere').innerText = 'Cancer!'
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.toggle('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
        } else if (bdayMonth === "july" && bDay >= 23){
            document.querySelector('#placeTextHere').innerText = 'Leo!'
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.toggle('hidden')
            
        } else if (bdayMonth === "august" && bDay <= 22 ) {
            document.querySelector('#placeTextHere').innerText = 'Leo!'
            
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.toggle('hidden')
            
        } else if (bdayMonth === "august" && bDay >= 23){
            document.querySelector('#placeTextHere').innerText = 'Virgo!'
            
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.toggle('hidden')
            
        } else if (bdayMonth === "september" && bDay <= 22 ) {
            document.querySelector('#placeTextHere').innerText = 'Virgo!'
            
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.toggle('hidden')
            
        } else if (bdayMonth === "september" && bDay >= 23){

            document.querySelector('#placeTextHere').innerText = 'Libra!'
           
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.toggle('hidden')
           
        } else if (bdayMonth === "october" && bDay <= 22 ) {

            document.querySelector('#placeTextHere').innerText = 'Libra!'
          
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.toggle('hidden')
            

        } else if (bdayMonth === "october" && bDay >= 23){

            
            document.querySelector('#placeTextHere').innerText = 'Scorpio!'
            
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.toggle('hidden')
            
        } else if (bdayMonth === "november" && bDay <= 21) {
            
            document.querySelector('#placeTextHere').innerText = 'Scorpio!'
           
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.toggle('hidden')
            
        } else if (bdayMonth === "november" && bDay >= 22){

            document.querySelector('#placeTextHere').innerText = 'Sagittarius!'
            
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.toggle('hidden')
            
        } else if (bdayMonth === "december" && bDay <= 21) {

            document.querySelector('#placeTextHere').innerText = 'Sagittarius!'
            
            aquarius.classList.add('hidden')
            cap.classList.add('hidden')
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.toggle('hidden')
            
        } else if (bdayMonth === "december" && bDay >= 22){
            document.querySelector('#placeTextHere').innerText = 'Capricorn!'
            
            pisces.classList.add('hidden')
            aries.classList.add('hidden')
            taurus.classList.add('hidden')
            gemini.classList.add('hidden')
            cancer.classList.add('hidden')
            leo.classList.add('hidden')
            virgo.classList.add('hidden')
            libra.classList.add('hidden')
            scorpio.classList.add('hidden')
            sag.classList.add('hidden')
            aquarius.classList.add('hidden')
            cap.classList.toggle('hidden')
        } else {
        document.querySelector('#placeTextHere').innerText = "Person That's Not Entering a Valid Date!"

    }
}